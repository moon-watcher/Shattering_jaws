
= Shattering jaws =============================================================


You are little Timmy. Be a good boy and pay attention to mom's advice. Exceed 
level 4 and get your reward. Be smart, you are the slowest thing out there, 
learn how to use boats to your advantage. It may be challenging sometimes, 
don't give up!

Shattering jaws a Sega Genesis/Megadrive game created for the Bitbit JAM#3. 
Almost every code is written from scratch. Some graphics are ripped off and 
others created by my and. No music at all.

Enjoy!


= Mun - @MoonWatcherMD =========================================== 2016-07-04 =